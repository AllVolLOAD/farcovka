from datetime import datetime
from sqlalchemy import BigInteger, Integer, String, DateTime, ForeignKey, JSON
from sqlalchemy.orm import mapped_column, Mapped, relationship
from typing import Optional

from app.models.db.base import Base


class WalletAccount(Base):
    __tablename__ = "wallet_accounts"
    __mapper_args__ = {"eager_defaults": True}
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.tg_id"), nullable=False, index=True)
    address: Mapped[str] = mapped_column(String(42), nullable=False, unique=True, index=True)
    chain_id: Mapped[int] = mapped_column(Integer, default=11155111)  # Sepolia testnet
    wallet_type: Mapped[str] = mapped_column(String(20), default="external")  # external/local/custodial
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default="now()")
    
    # Relationships
    wc_sessions: Mapped[list["WCSession"]] = relationship("WCSession", back_populates="wallet")
    orders: Mapped[list["Order"]] = relationship("Order", back_populates="wallet")
    
    def __repr__(self):
        return f"<WalletAccount id={self.id} address={self.address} type={self.wallet_type}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "address": self.address,
            "chain_id": self.chain_id,
            "wallet_type": self.wallet_type,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }


class WCSession(Base):
    __tablename__ = "wc_sessions"
    __mapper_args__ = {"eager_defaults": True}
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    wallet_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("wallet_accounts.id"), index=True)
    topic: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    peer_metadata: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    expiry: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="active")  # active/expired/disconnected
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default="now()")
    
    # Relationships
    wallet: Mapped[Optional["WalletAccount"]] = relationship("WalletAccount", back_populates="wc_sessions")
    
    def __repr__(self):
        return f"<WCSession id={self.id} topic={self.topic} status={self.status}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "wallet_id": self.wallet_id,
            "topic": self.topic,
            "peer_metadata": self.peer_metadata,
            "expiry": self.expiry.isoformat() if self.expiry else None,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }

