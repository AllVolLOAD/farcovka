from datetime import datetime
from decimal import Decimal

from sqlalchemy import BigInteger, DateTime, ForeignKey, Integer, Numeric, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.db.base import Base


class UserBalance(Base):
    __tablename__ = "user_balances"
    __table_args__ = (
        UniqueConstraint("user_id", "token", name="uq_user_balances_user_token"),
    )
    __mapper_args__ = {"eager_defaults": True}

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.tg_id"), index=True, nullable=False)
    token: Mapped[str] = mapped_column(String(10), nullable=False, default="USDT", index=True)
    balance: Mapped[Decimal] = mapped_column(Numeric(18, 8), nullable=False, default=0)
    last_updated: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

    def __repr__(self) -> str:
        return f"<UserBalance user_id={self.user_id} token={self.token} balance={self.balance}>"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "token": self.token,
            "balance": str(self.balance),
            "last_updated": self.last_updated.isoformat() if self.last_updated else None,
        }

