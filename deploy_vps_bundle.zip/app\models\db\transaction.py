from datetime import datetime
from decimal import Decimal
from sqlalchemy import Integer, String, DateTime, ForeignKey, Numeric
from sqlalchemy.orm import mapped_column, Mapped, relationship
from typing import Optional

from app.models.db.base import Base


class Transaction(Base):
    __tablename__ = "transactions"
    __mapper_args__ = {"eager_defaults": True}
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("orders.id"), index=True, nullable=True)
    tx_hash: Mapped[str] = mapped_column(String(66), unique=True, index=True)
    from_address: Mapped[str] = mapped_column(String(42))
    to_address: Mapped[str] = mapped_column(String(42))
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 8))
    chain_id: Mapped[int] = mapped_column(Integer)
    type: Mapped[str] = mapped_column(String(20))  # deposit/withdrawal
    status: Mapped[str] = mapped_column(String(20), default="pending", index=True)  # pending/confirmed/failed
    wallet_mode: Mapped[str] = mapped_column(String(10), default="COLD", index=True)
    confirmations: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default="now()")
    
    # Relationships
    order: Mapped[Optional["Order"]] = relationship("Order", back_populates="transactions")
    
    def __repr__(self):
        return f"<Transaction id={self.id} hash={self.tx_hash} type={self.type} status={self.status}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "order_id": self.order_id,
            "tx_hash": self.tx_hash,
            "from_address": self.from_address,
            "to_address": self.to_address,
            "amount": str(self.amount),
            "chain_id": self.chain_id,
            "type": self.type,
            "status": self.status,
            "wallet_mode": self.wallet_mode,
            "confirmations": self.confirmations,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }

