from dataclasses import dataclass


@dataclass
class BlockchainConfig:
    """Blockchain configuration (Vault, Registry, RPC)"""
    sepolia_rpc_url: str
    vault_v2_address: str
    vault_registry_address: str | None = None
    chain_id: int = 11155111  # Sepolia
    
    def __post_init__(self):
        """Validate addresses format"""
        if not self.vault_v2_address.startswith("0x"):
            raise ValueError("vault_v2_address must start with 0x")
        if len(self.vault_v2_address) != 42:
            raise ValueError("vault_v2_address must be 42 characters (0x + 40 hex)")

