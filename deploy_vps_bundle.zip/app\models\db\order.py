from datetime import datetime
from decimal import Decimal
from sqlalchemy import BigInteger, Integer, String, DateTime, ForeignKey, Numeric
from sqlalchemy.orm import mapped_column, Mapped, relationship
from typing import Optional

from app.models.db.base import Base


class Order(Base):
    __tablename__ = "orders"
    __mapper_args__ = {"eager_defaults": True}
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.tg_id"), index=True)
    wallet_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("wallet_accounts.id"), index=True)
    type: Mapped[str] = mapped_column(String(10))  # buy/sell
    currency_pair: Mapped[str] = mapped_column(String(10))  # USD/RUB
    amount_crypto: Mapped[Decimal] = mapped_column(Numeric(18, 8))  # Сумма в токенах (USDT)
    amount_fiat: Mapped[Decimal] = mapped_column(Numeric(12, 2))    # Сумма в фиате (RUB)
    rate: Mapped[Decimal] = mapped_column(Numeric(10, 4))           # Курс обмена
    status: Mapped[str] = mapped_column(String(20), default="pending", index=True)
    wallet_mode: Mapped[str] = mapped_column(String(10), default="COLD", index=True)
    # pending/deposit_wait/processing/completed/cancelled
    deposit_address: Mapped[Optional[str]] = mapped_column(String(42), nullable=True)  # Адрес для депозита
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default="now()")
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, onupdate=datetime.utcnow, nullable=True)
    
    # Relationships
    wallet: Mapped[Optional["WalletAccount"]] = relationship("WalletAccount", back_populates="orders")
    transactions: Mapped[list["Transaction"]] = relationship("Transaction", back_populates="order")
    
    def __repr__(self):
        return f"<Order id={self.id} type={self.type} status={self.status} amount={self.amount_crypto}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "wallet_id": self.wallet_id,
            "type": self.type,
            "currency_pair": self.currency_pair,
            "amount_crypto": str(self.amount_crypto),
            "amount_fiat": str(self.amount_fiat),
            "rate": str(self.rate),
            "status": self.status,
            "wallet_mode": self.wallet_mode,
            "deposit_address": self.deposit_address,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }

